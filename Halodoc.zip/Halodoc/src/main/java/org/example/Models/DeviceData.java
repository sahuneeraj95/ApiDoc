package org.example.Models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DeviceData {
      private int year;
      private int price;
      @JsonProperty("CPU model")
      private String cpu_model;
      @JsonProperty("Hard disk size")
      private String hard_disk_size;
}


/*
--data '{
   "name": "xxs IPHONE xx",
   "data": {
      "year": 2023,
      "price": 1849,
      "CPU model": "M1",
      "Hard disk size": "1 TB"
   }

 */
