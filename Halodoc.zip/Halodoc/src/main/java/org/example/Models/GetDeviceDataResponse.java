package org.example.Models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@Getter
@AllArgsConstructor
@Setter
public class GetDeviceDataResponse {
    String color;
    @JsonProperty("capacity GB")
    String capacity_GB;
}
