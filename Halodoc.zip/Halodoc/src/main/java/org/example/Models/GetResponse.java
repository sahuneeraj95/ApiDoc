package org.example.Models;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@Getter
@AllArgsConstructor
@Setter
public class GetResponse {
  String id;
  String name;
  @JsonProperty("data")
  GetDeviceDataResponse getDeviceDataResponse;
}
