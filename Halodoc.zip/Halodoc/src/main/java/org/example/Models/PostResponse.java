package org.example.Models;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Date;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Data
@AllArgsConstructor
public class PostResponse {
    private String id;
    private String name;

    @JsonProperty("data")
    private DeviceData deviceData;

    @JsonProperty("createdAt")
    private String date;

    public PostResponse() {
    }

    // ✅ Optionally, Add an All-Args Constructor

    public void setId(String id) { this.id = id; }

    public void setName(String name) { this.name = name; }

    public void setDeviceData(DeviceData deviceData) { this.deviceData = deviceData; }

    public void setDate(String date) { this.date = date; }

    @Override
    public String toString() {
        return "PostResponse{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", deviceData=" + deviceData +
                ", date='" + date + '\'' +
                '}';
    }
}


