import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.CustomLog;
import lombok.SneakyThrows;
import org.example.Models.DeviceData;
import org.example.Models.Devices;
import org.example.Models.GetResponse;
import org.example.Models.PostResponse;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.path.json.JsonPath;

import java.net.http.HttpRequest;
import java.util.List;

public class TestHalodoc {
   RequestSpecification requestSpecification;

  Devices devices = bodyRequest();
  String id = "";

  @SneakyThrows
  @Test(priority=0)
  public void post_Request(){
    RestAssured.baseURI = "https://api.restful-api.dev/objects";

    ObjectMapper mapperRequest = new ObjectMapper();

    String devicesRequest = mapperRequest.writeValueAsString(devices);

    Response response = RestAssured.given().log().all().header("Content-Type", "application/json")
                              .body(devicesRequest).post("");

    System.out.println("Response :"+ response.getBody().asString());
    ObjectMapper mapper = new ObjectMapper();

    JsonPath jsonPath = response.jsonPath();

    id = jsonPath.getString("id");
    System.out.println("id "+ id);
    PostResponse postResponse = mapper.readValue(response.getBody().asString(), PostResponse.class);

    String postResponseString = mapper.writeValueAsString(postResponse);
    System.out.println(postResponseString);
  }

  public static Devices bodyRequest(){
    DeviceData deviceData = DeviceData.builder().cpu_model("M1")

            .hard_disk_size("1 TB").price(1849).year(2023).build();
   return Devices.builder().name("xxs IPHONE xx").deviceData(deviceData).build();

  }
  // Base Class
// JA VA => Test
//     test.response
  //   test.validation
//   , DataProvider, DataUtils[][] , ValidationClass
// main => rEQUESTbUILDER, ResponseGenerator => builtRequest, Serializeit then deselireIt
// UTIls =>
  public static Devices upDate_bodyRequest(){
    DeviceData deviceData = DeviceData.builder().cpu_model("M1").hard_disk_size("1 TB").price(1849).year(2023).build();
    return Devices.builder().name("xxs IPHONE xx Updated").deviceData(deviceData).build();

  }
  @SneakyThrows
  @Test(priority=1)
  public void get_Request(){
    RestAssured.baseURI = "https://api.restful-api.dev/objects/";

    Response response = RestAssured.given().log().all().header("Content-Type", "application/json")
            .get("3");

    ObjectMapper mapper = new ObjectMapper();

    System.out.println("Response :"+ response.getBody().asString());
    GetResponse getResponse = mapper.readValue(response.getBody().asString(), GetResponse.class);

    System.out.println(getResponse.toString());

  }
  @SneakyThrows

  @Test(priority=2)
  public void put_Request(){
    RestAssured.baseURI = "https://api.restful-api.dev/objects/";

    ObjectMapper mapperRequest = new ObjectMapper();

    Devices devices = bodyRequest();

    String devicesRequest = mapperRequest.writeValueAsString(devices);
    Response response = RestAssured.given().log().all().header("Content-Type", "application/json")
            .body(devicesRequest).put(id);
    System.out.println("Response :"+ response.getBody().asString());

  }

  @Test(priority=3)
  public void delete_Request(){
    RestAssured.baseURI = "https://api.restful-api.dev/objects/";

    ObjectMapper mapperRequest = new ObjectMapper();
    Response response = RestAssured.given().log().all().header("Content-Type", "application/json")
            .delete(id);

    System.out.println("Response :"+ response.getBody().asString());

  }

}
